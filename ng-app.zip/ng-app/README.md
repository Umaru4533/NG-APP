# NG App

A Pen created on CodePen.

Original URL: [https://codepen.io/Umaru-Brima-Ensah/pen/gbaxRqo](https://codepen.io/Umaru-Brima-Ensah/pen/gbaxRqo).

